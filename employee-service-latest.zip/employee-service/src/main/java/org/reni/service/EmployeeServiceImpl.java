package org.reni.service;


import org.reni.entities.Employee;
import org.reni.exception.EmployeeNotFoundException;
import org.reni.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService{
    @Autowired
    private EmployeeRepository employeeRepository;
    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll()
                .stream().sorted((e1,e2)->e1.getId()-e2.getId())
                .collect(Collectors.toList());

    }

    @Override
    public Employee getEmployeeById(int id) {
        return
        employeeRepository.findById(id).
                orElseThrow(()->new EmployeeNotFoundException
                        ("Employee not found for id: "+id));

    }

    @Override
    public String addEmployee(Employee employee) {
        employeeRepository.save(employee);
        return "Employee added successfully";
    }

    @Override
    public String updateEmployee(int id, Employee employee) {

        Optional<Employee> empOpt=
                employeeRepository.findById(id);
        if(empOpt.isEmpty()){
            throw new EmployeeNotFoundException("Employee not found for id: "+id);
        }
        Employee emp=empOpt.get();
        if(employee.getName()!=null){
            emp.setName(employee.getName());
        }
        if(employee.getGender()!=null) {
            emp.setGender(employee.getGender());
        }
        if(employee.getAge()!=0) {
            emp.setAge(employee.getAge());
        }
        if(employee.getSalary()!=0) {
            emp.setSalary(employee.getSalary());
        }
        return "Employee updated successfully";
    }

    @Override
    public String deleteEmployee(int id) {
        Optional<Employee> empOpt=
                employeeRepository.findById(id);
        if(empOpt.isEmpty()){
            throw new EmployeeNotFoundException("Employee not found for id: "+id);
        }
        employeeRepository.deleteById(id);
        return "Employee deleted successfully";
    }
}
