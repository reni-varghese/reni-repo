package org.reni.service;


import org.reni.entities.Employee;

import java.util.List;

public interface EmployeeService {
    List<Employee> getAllEmployees();
    Employee getEmployeeById(int id);
    String addEmployee(Employee employee);
    String updateEmployee(int id,Employee employee);
    String deleteEmployee(int id);
}
